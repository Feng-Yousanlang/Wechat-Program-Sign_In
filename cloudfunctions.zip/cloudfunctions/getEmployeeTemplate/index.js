// 获取员工导入Excel模板
const cloud = require('wx-server-sdk')
const xlsx = require('xlsx')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

exports.main = async () => {
  try {
    const db = cloud.database()
    
    // 检查是否已有模板
    try {
      const configResult = await db.collection('config').where({
        key: 'employee_template'
      }).get()
      
      if (configResult.data && configResult.data.length > 0) {
        const template = configResult.data[0]
        return {
          success: true,
          fileID: template.fileID,
          message: '模板已存在'
        }
      }
    } catch (err) {
      // 如果集合不存在，继续创建模板
      console.log('config集合不存在，将创建新模板')
    }
    
    // 创建Excel模板
    const workbook = xlsx.utils.book_new()
    
    // 表头数据
    const headers = [
      ['姓名', '手机号', '工号', '部门', '备注']
    ]
    
    // 示例数据
    const examples = [
      ['张三', '13800138000', 'EMP001', '技术部', '示例数据，请删除'],
      ['李四', '13800138001', 'EMP002', '销售部', '示例数据，请删除']
    ]
    
    // 合并数据
    const sheetData = [...headers, ...examples]
    
    // 创建工作表
    const worksheet = xlsx.utils.aoa_to_sheet(sheetData)
    
    // 设置列宽
    worksheet['!cols'] = [
      { width: 15 }, // 姓名
      { width: 15 }, // 手机号
      { width: 15 }, // 工号
      { width: 15 }, // 部门
      { width: 20 }  // 备注
    ]
    
    // 添加工作表到工作簿
    xlsx.utils.book_append_sheet(workbook, worksheet, '员工导入模板')
    
    // 生成Excel文件
    const excelBuffer = xlsx.write(workbook, { type: 'buffer', bookType: 'xlsx' })
    
    // 上传到云存储
    const cloudPath = `templates/employee_import_template_${Date.now()}.xlsx`
    const uploadResult = await cloud.uploadFile({
      cloudPath,
      fileContent: excelBuffer
    })
    
    // 保存模板信息到数据库
    try {
      await db.collection('config').add({
        data: {
          key: 'employee_template',
          fileID: uploadResult.fileID,
          createTime: new Date(),
          description: '员工导入Excel模板'
        }
      })
    } catch (saveErr) {
      console.log('保存模板配置失败:', saveErr.message)
      // 即使保存失败，也返回模板文件
    }
    
    return {
      success: true,
      fileID: uploadResult.fileID,
      message: '模板创建成功'
    }
    
  } catch (error) {
    console.error('获取模板失败:', error)
    return {
      success: false,
      message: '获取模板失败：' + error.message
    }
  }
}
