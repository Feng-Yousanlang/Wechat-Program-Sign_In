const cloud = require('wx-server-sdk')
const XLSX = require('xlsx')

cloud.init()
const db = cloud.database()

exports.main = async (event, context) => {
  const { noticeId } = event
  if (!noticeId) {
    return { success: false, message: '缺少noticeId' }
  }

  try {
    // 获取通知
    const noticeRes = await db.collection('notices').doc(noticeId).get()
    const notice = noticeRes.data

    // 收集用户ID
    const userIds = new Set([...(notice.viewedUsers || []), ...(notice.downloadedUsers || [])])

    // 获取用户信息
    let userMap = {}
    if (userIds.size) {
      const usersRes = await db.collection('users').where({ _id: db.command.in([...userIds]) }).get()
      usersRes.data.forEach(u => {
        userMap[u._id] = u
      })
    }

    // 获取部门信息
    const deptRes = await db.collection('departments').get()
    const deptMap = {}
    deptRes.data.forEach(d => {
      (d.users || []).forEach(uid => {
        deptMap[uid] = d.name
      })
    })

    // 构造数据行
    const rows = [['姓名', '账号', '部门', '状态']]

    const pushRow = (uid, status) => {
      const user = userMap[uid] || {}
      const name = user.name || user.nickName || user.username || '未知'
      const account = user.username || uid
      const dept = deptMap[uid] || '未知部门'
      rows.push([name, account, dept, status])
    }

    ;(notice.viewedUsers || []).forEach(uid => pushRow(uid, '已查看'))
    ;(notice.downloadedUsers || []).forEach(uid => pushRow(uid, '已下载'))

    // 生成工作簿
    const ws = XLSX.utils.aoa_to_sheet(rows)
    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, ws, '统计')

    const buffer = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' })

    const filePath = `exports/notice_stats_${noticeId}_${Date.now()}.xlsx`

    const uploadRes = await cloud.uploadFile({
      cloudPath: filePath,
      fileContent: buffer
    })

    return { success: true, fileID: uploadRes.fileID }
  } catch (err) {
    console.error(err)
    return { success: false, message: '导出失败' }
  }
} 