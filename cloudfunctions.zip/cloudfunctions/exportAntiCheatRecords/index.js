// 导出打卡记录
const cloud = require('wx-server-sdk')
const xlsx = require('xlsx')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

function formatShanghai(ts) {
  const d = new Date(ts)
  // 转为UTC再加8小时，避免服务器时区影响
  const utc = d.getTime() + d.getTimezoneOffset() * 60000
  const sh = new Date(utc + 8 * 3600000)
  const y = sh.getFullYear()
  const m = String(sh.getMonth() + 1).padStart(2, '0')
  const da = String(sh.getDate()).padStart(2, '0')
  const h = String(sh.getHours()).padStart(2, '0')
  const mi = String(sh.getMinutes()).padStart(2, '0')
  const s = String(sh.getSeconds()).padStart(2, '0')
  return `${y}-${m}-${da} ${h}:${mi}:${s}`
}

function getTs(val) {
  if (!val) return Date.now()
  if (typeof val === 'number') return val
  const d = new Date(val)
  return isNaN(d.getTime()) ? Date.now() : d.getTime()
}

// 获取指定月份的天数
function getDaysInMonth(year, month) {
  return new Date(year, month, 0).getDate()
}

// 判断打卡时间属于上午还是下午
function getTimeSlot(hour) {
  if (hour < 12) return 'morning' // 上午
  return 'afternoon' // 下午
}

// 生成考勤状态文本
function getAttendanceStatus(record, businessTripDate = null) {
  if (!record) {
    // 如果没有打卡记录，检查是否有出差申请
    if (businessTripDate) return '出差'
    return '缺卡'
  }
  
  // 如果是出差打卡
  if (record.type === 'business_trip') return '出差'
  
  // 如果有防作弊问题
  if (record.hasProblem) return '异常'
  
  // 根据打卡状态判断
  switch (record.status) {
    case 'late': return '迟到'
    case 'early_leave': return '早退'
    case 'normal': return '正常'
    default: return '正常'
  }
}

// 安全的日期转换函数
function safeDateParse(dateVal) {
  if (!dateVal) return null

  // 已是 Date 实例
  if (dateVal instanceof Date) {
    if (!isNaN(dateVal.getTime())) return dateVal
    return null
  }

  // 云开发可能返回可序列化对象，尝试 new Date 直接解析
  if (typeof dateVal === 'object') {
    const d = new Date(dateVal)
    if (!isNaN(d.getTime())) return d
    // 常见形态：{ $date: 123456789000 } 或 { toDate: () => Date }
    if (dateVal.$date) {
      const d2 = new Date(dateVal.$date)
      if (!isNaN(d2.getTime())) return d2
    }
    if (typeof dateVal.toDate === 'function') {
      const d3 = dateVal.toDate()
      if (d3 instanceof Date && !isNaN(d3.getTime())) return d3
    }
    return null
  }

  // 数字时间戳
  if (typeof dateVal === 'number') {
    const d = new Date(dateVal)
    return isNaN(d.getTime()) ? null : d
  }

  // 字符串多格式
  if (typeof dateVal === 'string') {
    if (dateVal.match(/^\d{4}-\d{2}-\d{2}$/)) {
      return new Date(dateVal + 'T00:00:00')
    }
    if (dateVal.match(/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/)) {
      return new Date(dateVal.replace(' ', 'T'))
    }
    const d = new Date(dateVal)
    if (!isNaN(d.getTime())) return d
  }

  return null
}

// 检查日期是否在出差范围内
function isDateInBusinessTripRange(currentDate, startDate, endDate) {
  if (!startDate || !endDate) return false
  
  const start = safeDateParse(startDate)
  const end = safeDateParse(endDate)
  
  if (!start || !end) {
    return false
  }
  
  // 重置时间为00:00:00，只比较日期
  const current = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate())
  const startDay = new Date(start.getFullYear(), start.getMonth(), start.getDate())
  const endDay = new Date(end.getFullYear(), end.getMonth(), end.getDate())
  
  const result = current >= startDay && current <= endDay
  
  
  return result
}

exports.main = async (event) => {
  try {
    // 导出函数开始
    
    const { startDate, endDate, filterStatus = 'all', filterLevel = 'all', userId = '', department = 'all' } = event
    
    
    
    const db = cloud.database()
    const _ = db.command

    const collectionName = 'checkRecord'

    // 先检查数据库中的记录类型分布
    // 检查数据库记录类型分布（非关键，可忽略失败）
    try {
      const typeStats = await db.collection(collectionName).aggregate()
        .group({
          _id: '$type',
          count: db.command.aggregate.sum(1)
        })
        .end()
    } catch (e) {
      
    }
    
    // 构建查询条件
    let whereConditions = {}
    
    // 状态筛选（只有在明确选择时才添加条件）
    if (filterStatus && filterStatus !== 'all') {
      whereConditions.processStatus = filterStatus
    }
    
    // 问题筛选（只有在明确选择时才添加条件，并且增加容错）
    if (filterLevel === 'problem') {
      // 查询有问题的记录：包括 hasProblem=true 或者 processStatus='pending'
      whereConditions = _.or([
        { hasProblem: true },
        { processStatus: 'pending' }
      ])
    } else if (filterLevel === 'normal') {
      // 查询无问题的记录：包括 hasProblem=false 或者 processStatus='noNeed'
      whereConditions = _.or([
        { hasProblem: false },
        { processStatus: 'noNeed' }
      ])
    }
    
    // 时间筛选
    if (startDate) {
      const startTime = new Date(startDate + ' 00:00:00')
      if (Object.keys(whereConditions).length === 0) {
        whereConditions.createTime = _.gte(startTime)
      } else {
        whereConditions = _.and(whereConditions, { createTime: _.gte(startTime) })
      }
    }
    
    if (endDate) {
      const endTime = new Date(endDate + ' 23:59:59')
      if (Object.keys(whereConditions).length === 0) {
        whereConditions.createTime = _.lte(endTime)
      } else if (whereConditions.createTime) {
        whereConditions.createTime = _.and(whereConditions.createTime, _.lte(endTime))
      } else {
        whereConditions = _.and(whereConditions, { createTime: _.lte(endTime) })
      }
    }
    
    // 部门筛选
    if (department && department !== 'all') {
      if (Object.keys(whereConditions).length === 0) {
        whereConditions.department = department
      } else {
        whereConditions = _.and(whereConditions, { department: department })
      }
    }
    
    // 用户筛选
    if (userId && userId !== 'all') {
      if (Object.keys(whereConditions).length === 0) {
        whereConditions.userId = userId
      } else {
        whereConditions = _.and(whereConditions, { userId: userId })
      }
    }
    
    const coll = db.collection(collectionName)
    
    // 如果没有查询条件，查询所有记录
    let all = []
    if (Object.keys(whereConditions).length === 0) {
      
      // 查询所有记录，分页获取
      let skip = 0
      const pageSize = 100
      let hasMore = true
      
      while (hasMore) {
        const res = await coll.orderBy('createTime', 'desc').skip(skip).limit(pageSize).get()
        if (res && Array.isArray(res.data)) {
          all = all.concat(res.data)
          hasMore = res.data.length === pageSize
          skip += pageSize
        } else {
          hasMore = false
        }
      }
    } else {
      
      // 有查询条件时，先统计总数再分页获取
      const countRes = await coll.where(whereConditions).count()
      const total = countRes.total || 0
      
      const pageSize = 100
      
      for (let skip = 0; skip < total; skip += pageSize) {
        const res = await coll.where(whereConditions).orderBy('createTime', 'desc').skip(skip).limit(pageSize).get()
        if (res && Array.isArray(res.data)) all = all.concat(res.data)
      }
    }
    
    
    
    if (all.length === 0) {
      return { 
        success: false, 
        message: '没有找到相关记录，请检查筛选条件或确认数据库中有打卡数据',
        debug: {
          whereConditions: whereConditions,
          filterStatus: filterStatus,
          filterLevel: filterLevel,
          startDate: startDate,
          endDate: endDate,
          userId: userId,
          department: department
        }
      }
    }

    // 获取用户列表
    const users = await db.collection('users').get()
    const userMap = {}
    users.data.forEach(user => {
      userMap[user._id] = user
    })
    
    

    // 获取出差申请记录
    
    let businessTripRecords = []
    try {
      const businessTripRes = await db.collection('businessTripApplications').get()
      businessTripRecords = businessTripRes.data || []
      
      
      // 如果没有数据，尝试其他可能的表名
      if (businessTripRecords.length === 0) {
        const possibleTables = ['businessTripApplication', 'businessTrip', 'business_trip', 'trip', 'travel', 'application']
        for (const tableName of possibleTables) {
          try {
            const testRes = await db.collection(tableName).get()
            if (testRes.data.length > 0) {
              
              businessTripRecords = testRes.data
              break
            }
          } catch (e) {
            // 静默处理错误
          }
        }
      }
    } catch (e) {
      
      businessTripRecords = []
    }
    
    // 确定月份范围
    let startMonth = new Date()
    let endMonth = new Date()
    
    if (startDate) {
      startMonth = new Date(startDate)
    }
    if (endDate) {
      endMonth = new Date(endDate)
    }
    
    // 如果只指定了开始日期，结束日期设为同月最后一天
    if (startDate && !endDate) {
      endMonth = new Date(startMonth.getFullYear(), startMonth.getMonth() + 1, 0)
    }
    // 如果只指定了结束日期，开始日期设为同月第一天
    if (!startDate && endDate) {
      startMonth = new Date(endMonth.getFullYear(), endMonth.getMonth(), 1)
    }
    
    

    // 生成考勤表数据
    const attendanceData = []
    
    // 表头：用户信息 + 日期
    const headers = ['员工姓名', '工号', '部门']
    const daysInMonth = getDaysInMonth(endMonth.getFullYear(), endMonth.getMonth() + 1)
    
    
    
    // 添加日期列（上午和下午）
    for (let day = 1; day <= daysInMonth; day++) {
      headers.push(`${day}日`)
    }
    
    attendanceData.push(headers)
    
    
    // 为每个用户生成考勤行
    for (const userId in userMap) {
      const user = userMap[userId]
      const userRecords = all.filter(record => record.userId === userId)
      
      // 获取该用户的出差申请记录
      const userBusinessTrips = businessTripRecords.filter(bt => {
        const possibleUserIdFields = ['userId', 'user_id', 'user', 'openid', '_openid']
        let foundUserId = null
        
        for (const field of possibleUserIdFields) {
          if (bt[field]) {
            foundUserId = bt[field]
            break
          }
        }
        
        return foundUserId === userId
      })
      
      // 按日期分组用户记录
      const dailyRecords = {}
      userRecords.forEach(record => {
        const date = new Date(record.createTime)
        const day = date.getDate()
        const hour = date.getHours()
        const timeSlot = getTimeSlot(hour)
        
        if (!dailyRecords[day]) {
          dailyRecords[day] = { morning: null, afternoon: null }
        }
        
        // 如果该时间段已有记录，选择更早的（上班）或更晚的（下班）
        if (timeSlot === 'morning') {
          if (!dailyRecords[day].morning || record.createTime < dailyRecords[day].morning.createTime) {
            dailyRecords[day].morning = record
          }
        } else {
          if (!dailyRecords[day].afternoon || record.createTime > dailyRecords[day].afternoon.createTime) {
            dailyRecords[day].afternoon = record
          }
        }
      })
      
      // 生成用户考勤行
      const userRow = [user.username || '未知', user.employeeId || '', user.department || '']
      
      for (let day = 1; day <= daysInMonth; day++) {
        const dayRecords = dailyRecords[day]
        
        // 检查该日期是否有出差申请（若有则整天视为出差）
        const businessTripDate = userBusinessTrips.find(bt => {
          // 只考虑已通过的出差申请，排除待审核和已拒绝的
          if (bt.status !== 'approved') {
            return false
          }
          
          const currentDate = new Date(endMonth.getFullYear(), endMonth.getMonth(), day)
          let startDate = bt.createTime
          let endDate = bt.returnDate || bt.createTime
          return isDateInBusinessTripRange(currentDate, startDate, endDate)
        })
        
        let dayStatus = ''
        
        if (businessTripDate) {
          // 有出差时，全天直接标记为“出差”
          dayStatus = '出差'
        } else if (dayRecords) {
          const morningStatus = getAttendanceStatus(dayRecords.morning, null)
          const afternoonStatus = getAttendanceStatus(dayRecords.afternoon, null)
          
          if (morningStatus === '缺卡' && afternoonStatus === '缺卡') {
            dayStatus = '缺卡'
          } else if (morningStatus === '缺卡') {
            dayStatus = `上午缺卡，下午${afternoonStatus}`
          } else if (afternoonStatus === '缺卡') {
            dayStatus = `上午${morningStatus}，下午缺卡`
          } else {
            dayStatus = `上午${morningStatus}，下午${afternoonStatus}`
          }
        } else {
          dayStatus = '缺卡'
        }
        
        userRow.push(dayStatus)
      }
      
      attendanceData.push(userRow)
    }
    
    
    
    // 统计出差状态
    let businessTripCount = 0
    attendanceData.forEach((row, index) => {
      if (index === 0) return // 跳过表头
      for (let i = 3; i < row.length; i++) { // 从第4列开始是日期
        if (row[i] && row[i].includes('出差')) {
          businessTripCount++
        }
      }
    })
    
    
    // 创建工作簿和工作表
    const workbook = xlsx.utils.book_new()
    const worksheet = xlsx.utils.aoa_to_sheet(attendanceData)
    
    // 设置列宽
    const colWidths = [{ width: 15 }, { width: 15 }, { width: 15 }] // 前三列固定宽度
    for (let i = 0; i < daysInMonth; i++) {
      colWidths.push({ width: 20 }) // 日期列宽度
    }
    worksheet['!cols'] = colWidths
    
    // 添加工作表
    const monthName = `${endMonth.getFullYear()}年${endMonth.getMonth() + 1}月`
    xlsx.utils.book_append_sheet(workbook, worksheet, `${monthName}考勤表`)
    
    // 生成Excel文件
    const excelBuffer = xlsx.write(workbook, { type: 'buffer', bookType: 'xlsx' })
    const cloudPath = `exports/attendance_${endMonth.getFullYear()}_${String(endMonth.getMonth() + 1).padStart(2, '0')}.xlsx`
    const uploadResult = await cloud.uploadFile({ cloudPath, fileContent: excelBuffer })
    
    return { 
      success: true, 
      message: '导出成功', 
      fileID: uploadResult.fileID, 
      count: attendanceData.length - 1, // 减去表头行
      month: monthName
    }
    
  } catch (error) {
    console.error('导出考勤表失败:', error)
    return { success: false, message: '导出失败：' + error.message }
  }
}
