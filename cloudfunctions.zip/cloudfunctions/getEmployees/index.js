// 获取员工列表
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

exports.main = async () => {
  try {
    const db = cloud.database()
    
    const result = await db.collection('users').get()
    
    return {
      success: true,
      data: result.data
    }
    
  } catch (error) {
    console.error('获取员工列表失败:', error)
    return {
      success: false,
      message: '获取员工列表失败：' + error.message
    }
  }
}
