const cloud = require('wx-server-sdk')

cloud.init()
const db = cloud.database()

exports.main = async (event, context) => {
  const { noticeId, userId, action } = event
  
  if (!noticeId || !userId || !action) {
    console.log('参数缺失:', { noticeId, userId, action })
    return { 
      success: false, 
      message: '缺少必要参数' 
    }
  }

  // 验证用户ID
  if (!userId || userId === '' || userId === 'null' || userId === 'undefined') {
    console.error('用户ID无效:', userId)
    return {
      success: false,
      message: '用户ID无效'
    }
  }
  
  const userIdStr = String(userId)

  try {
    const _ = db.command
    
    // 获取当前通知记录
    const noticeRes = await db.collection('notices').doc(noticeId).get()
    if (!noticeRes.data) {
      console.log('通知不存在:', noticeId)
      return { 
        success: false, 
        message: '通知不存在' 
      }
    }
    
    const notice = noticeRes.data
    
    // 初始化缺失的字段
    if (!Array.isArray(notice.viewedUsers)) {
      notice.viewedUsers = []
    }
    
    if (!Array.isArray(notice.downloadedUsers)) {
      notice.downloadedUsers = []
    }
    
    let updateData = {}
    
    if (action === 'view') {
      // 确保 viewedUsers 是数组
      const currentViewedUsers = Array.isArray(notice.viewedUsers) ? notice.viewedUsers : []
      
      // 检查用户是否已经查看过
      if (!currentViewedUsers.includes(userIdStr)) {
        // 使用 addToSet 确保不重复添加
        updateData.viewedUsers = _.addToSet(userIdStr)
      }
    } else if (action === 'download') {
      // 确保 downloadedUsers 是数组
      const currentDownloadedUsers = Array.isArray(notice.downloadedUsers) ? notice.downloadedUsers : []
      
      // 检查用户是否已经下载过
      if (!currentDownloadedUsers.includes(userIdStr)) {
        // 使用 addToSet 确保不重复添加
        updateData.downloadedUsers = _.addToSet(userIdStr)
      }
    } else {
      console.log('无效的操作类型:', action)
      return { 
        success: false, 
        message: '无效的操作类型' 
      }
    }

    // 只有在需要更新时才执行更新操作
    if (Object.keys(updateData).length > 0) {
      await db.collection('notices').doc(noticeId).update({
        data: updateData
      })
      
      console.log(`更新通知统计成功: noticeId=${noticeId}, userId=${userIdStr}, action=${action}`)
      
    } else {
      console.log(`无需更新: noticeId=${noticeId}, userId=${userIdStr}, action=${action}`)
    }

    return { 
      success: true, 
      message: '操作成功' 
    }
  } catch (err) {
    console.error('更新通知统计失败:', err)
    return { 
      success: false, 
      message: '更新失败: ' + err.message 
    }
  }
}
