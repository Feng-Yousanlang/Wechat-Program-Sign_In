// 导入员工数据
const cloud = require('wx-server-sdk')
const xlsx = require('xlsx')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

exports.main = async (event) => {
  try {
    const { fileID } = event
    
    if (!fileID) {
      return {
        success: false,
        message: '文件ID不能为空'
      }
    }
    
    // 下载Excel文件
    const downloadResult = await cloud.downloadFile({
      fileID: fileID
    })
    
    // 读取Excel文件
    const workbook = xlsx.read(downloadResult.fileContent, { type: 'buffer' })
    const sheetName = workbook.SheetNames[0]
    const worksheet = workbook.Sheets[sheetName]
    
    // 转换为JSON数据
    const jsonData = xlsx.utils.sheet_to_json(worksheet, { header: 1 })
    
    // 跳过表头，处理数据行
    const employees = []
    for (let i = 1; i < jsonData.length; i++) {
      const row = jsonData[i]
      if (row.length >= 4 && row[0] && row[1] && row[2] && row[3]) {
        employees.push({
          name: row[0],
          phone: row[1],
          employeeId: row[2],
          department: row[3],
          remark: row[4] || '',
          createTime: new Date()
        })
      }
    }
    
    if (employees.length === 0) {
      return {
        success: false,
        message: 'Excel文件中没有有效数据'
      }
    }
    
    // 导入到数据库
    const db = cloud.database()
    let successCount = 0
    let failCount = 0
    
    for (const employee of employees) {
      try {
        // 检查工号是否已存在
        const existing = await db.collection('users').where({
          employeeId: employee.employeeId
        }).get()
        
        if (existing.data.length === 0) {
          // 添加新员工
          await db.collection('users').add({
            data: {
              username: employee.name,
              name: employee.name,
              phone: employee.phone,
              employeeId: employee.employeeId,
              department: employee.department,
              role: 'employee',
              createTime: employee.createTime,
              creator: 'import'
            }
          })
          successCount++
        } else {
          failCount++
          console.log(`工号 ${employee.employeeId} 已存在，跳过`)
        }
      } catch (err) {
        failCount++
        console.error(`导入员工 ${employee.name} 失败:`, err.message)
      }
    }
    
    return {
      success: true,
      message: `导入完成：成功 ${successCount} 人，失败 ${failCount} 人`,
      data: {
        total: employees.length,
        success: successCount,
        fail: failCount
      }
    }
    
  } catch (error) {
    console.error('导入员工失败:', error)
    return {
      success: false,
      message: '导入失败：' + error.message
    }
  }
}
