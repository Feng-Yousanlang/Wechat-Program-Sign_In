// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()

// 云函数入口函数
exports.main = async (event, context) => {
  try {
    const { recordId, newStatus, note = '', adminId = 'admin' } = event

    if (!recordId || !newStatus) {
      return {
        success: false,
        message: '缺少必要参数'
      }
    }

    // 验证状态值
    const validStatuses = ['pending', 'resolved', 'noNeed', 'normal']
    if (!validStatuses.includes(newStatus)) {
      return {
        success: false,
        message: '无效的状态值'
      }
    }

    // 读取当前记录
    const recordRes = await db.collection('checkRecord').doc(recordId).get()
    if (!recordRes.data) {
      return {
        success: false,
        message: '记录不存在'
      }
    }

    // 更新记录 - 添加处理状态字段
    const updateData = {
      processStatus: newStatus,
      processTime: new Date(),
      processNote: note || '',
      processBy: adminId
    }

    // 执行更新
    await db.collection('checkRecord').doc(recordId).update({
      data: updateData
    })

    // 重新读取更新后的记录
    const updatedRes = await db.collection('checkRecord').doc(recordId).get()
    const updatedRecord = updatedRes.data

    return {
      success: true,
      message: '状态更新成功',
      data: updatedRecord
    }

  } catch (error) {
    console.error('更新防作弊处理状态失败:', error)
    return {
      success: false,
      message: '更新失败: ' + error.message
    }
  }
}
