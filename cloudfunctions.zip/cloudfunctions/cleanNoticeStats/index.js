const cloud = require('wx-server-sdk')

cloud.init()
const db = cloud.database()

exports.main = async (event, context) => {
  const { noticeId, targetUserId } = event
  
  try {
    if (!noticeId) {
      return {
        success: false,
        message: '缺少通知ID'
      }
    }
    
    // 获取通知记录
    const noticeRes = await db.collection('notices').doc(noticeId).get()
    if (!noticeRes.data) {
      return {
        success: false,
        message: '通知不存在'
      }
    }
    
    const notice = noticeRes.data
    
    let updateData = {}
    
    if (targetUserId) {
      // 清理特定用户ID
      const currentViewedUsers = Array.isArray(notice.viewedUsers) ? notice.viewedUsers : []
      const currentDownloadedUsers = Array.isArray(notice.downloadedUsers) ? notice.downloadedUsers : []
      
      const newViewedUsers = currentViewedUsers.filter(uid => uid !== targetUserId)
      const newDownloadedUsers = currentDownloadedUsers.filter(uid => uid !== targetUserId)
      
      if (newViewedUsers.length !== currentViewedUsers.length) {
        updateData.viewedUsers = newViewedUsers
      }
      
      if (newDownloadedUsers.length !== currentDownloadedUsers.length) {
        updateData.downloadedUsers = newDownloadedUsers
      }
    } else {
      // 清理所有统计数据
      updateData.viewedUsers = []
      updateData.downloadedUsers = []
    }
    
    if (Object.keys(updateData).length > 0) {
      await db.collection('notices').doc(noticeId).update({
        data: updateData
      })
      
      return {
        success: true,
        message: '清理成功',
        data: updateData
      }
    } else {
      return {
        success: true,
        message: '无需清理',
        data: {}
      }
    }
    
  } catch (err) {
    console.error('❌ 清理失败:', err)
    return {
      success: false,
      message: '清理失败: ' + err.message
    }
  }
}
