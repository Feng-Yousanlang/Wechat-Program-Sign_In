// 修改密码云函数
const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()

exports.main = async (event, context) => {
  const { oldPassword, newPassword, userId } = event
  const wxContext = cloud.getWXContext()

  try {
    // 验证参数
    if (!oldPassword || !newPassword || !userId) {
      return {
        success: false,
        message: '参数不完整'
      }
    }

    // 验证新密码长度
    if (newPassword.length < 6) {
      return {
        success: false,
        message: '新密码至少6位'
      }
    }

    // 查询用户信息
    const userRes = await db.collection('users').doc(userId).get()
    if (!userRes.data) {
      return {
        success: false,
        message: '用户不存在'
      }
    }

    const user = userRes.data

    // 验证旧密码
    if (user.password !== oldPassword) {
      return {
        success: false,
        message: '当前密码错误'
      }
    }

    // 检查新密码是否与旧密码相同
    if (oldPassword === newPassword) {
      return {
        success: false,
        message: '新密码不能与当前密码相同'
      }
    }

    // 更新密码
    await db.collection('users').doc(userId).update({
      data: {
        password: newPassword,
        updateTime: new Date()
      }
    })

    return {
      success: true,
      message: '密码修改成功'
    }

  } catch (err) {
    console.error('修改密码失败:', err)
    return {
      success: false,
      message: '修改失败，请重试'
    }
  }
}
