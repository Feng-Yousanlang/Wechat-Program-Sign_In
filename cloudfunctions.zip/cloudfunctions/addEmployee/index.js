// 添加员工
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

exports.main = async (event) => {
  try {
    const { name, phone, employeeId, department } = event
    
    if (!name || !phone || !employeeId || !department) {
      return {
        success: false,
        message: '请填写完整信息'
      }
    }
    
    const db = cloud.database()
    
    // 检查工号是否已存在
    const existing = await db.collection('users').where({
      employeeId: employeeId
    }).get()
    
    if (existing.data.length > 0) {
      return {
        success: false,
        message: '工号已存在'
      }
    }
    
    // 添加员工
    const result = await db.collection('users').add({
      data: {
        username: name,
        name: name,
        phone: phone,
        employeeId: employeeId,
        department: department,
        role: 'employee',
        createTime: new Date(),
        creator: 'admin'
      }
    })
    
    return {
      success: true,
      message: '添加成功',
      data: result
    }
    
  } catch (error) {
    console.error('添加员工失败:', error)
    return {
      success: false,
      message: '添加失败：' + error.message
    }
  }
}
