// 云函数：获取（或登记）设备指纹基准
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()

exports.main = async (event, context) => {
  const { userId, username, employeeId, currentFingerprint, deviceInfo } = event || {}
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID || ''
  try {
    if (!userId && !username && !employeeId) {
      return { success: false, code: 'INVALID_ARG', message: '缺少用户标识(userId/username/employeeId)' }
    }

    // 仅按账号维度匹配（不依赖 openid）
    let baselineRes = await db.collection('deviceFingerprints')
      .where({ userId })
      .orderBy('createTime', 'asc')
      .limit(1)
      .get()

    if (!baselineRes || baselineRes.data.length === 0) {
      const orConds = []
      if (username) orConds.push({ username })
      if (employeeId) orConds.push({ employeeId })
      if (orConds.length > 0) {
        baselineRes = await db.collection('deviceFingerprints')
          .where(db.command.or(orConds))
          .orderBy('createTime', 'asc')
          .limit(1)
          .get()
      } else {
        baselineRes = { data: [] }
      }
    }

    if (baselineRes.data.length > 0) {
      const base = baselineRes.data[0]
      return {
        success: true,
        baselineFingerprint: base.fingerprint,
        baselineDevice: base.deviceInfo && base.deviceInfo.device,
        isNewBaseline: false
      }
    }

    // 无任何基准，登记一次
    if (!currentFingerprint) {
      return { success: false, code: 'NO_BASELINE_AND_NO_CURRENT', message: '无基准且未提供当前指纹' }
    }

    await db.collection('deviceFingerprints').add({
      data: {
        userId: userId || null,
        username: username || null,
        employeeId: employeeId || null,
        _openid: openid || null,
        fingerprint: currentFingerprint,
        deviceInfo: deviceInfo || {},
        createTime: new Date(),
        ipAddress: 'unknown',
        userAgent: `WeChat/${(wxContext && wxContext.WXAPPID) || 'cloud'}`
      }
    })

    return {
      success: true,
      baselineFingerprint: currentFingerprint,
      baselineDevice: deviceInfo && deviceInfo.device,
      isNewBaseline: true
    }
  } catch (err) {
    console.error('getDeviceBaseline failed:', err)
    return { success: false, code: 'ERROR', message: err && err.message }
  }
}


