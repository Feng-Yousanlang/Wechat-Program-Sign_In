// 删除员工
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

exports.main = async (event) => {
  try {
    const { id } = event
    
    if (!id) {
      return {
        success: false,
        message: '员工ID不能为空'
      }
    }
    
    const db = cloud.database()
    
    // 删除员工
    const result = await db.collection('users').doc(id).remove()
    
    return {
      success: true,
      message: '删除成功',
      data: result
    }
    
  } catch (error) {
    console.error('删除员工失败:', error)
    return {
      success: false,
      message: '删除失败：' + error.message
    }
  }
}
